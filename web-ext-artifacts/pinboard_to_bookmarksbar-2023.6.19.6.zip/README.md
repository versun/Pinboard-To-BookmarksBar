# Pinboard-To-BookmarksBar
This is a browser extension that imports bookmarks from Pinboard into your browser's bookmarks bar.

If you have any additional features you would like this extension to have, please let me know.

### Install
[Firefox Add-ons Store](https://addons.mozilla.org/en-US/firefox/addon/pinboard-to-bookmarksbar/)
